#include "swap.c"

int buf[2] = {1,2};
int ba = 2;

void func() {}

int main(){
    swap();
    return 0;
}
