#include "util.c"

int main() {
    int n = 3;
    pointers(n);
    condition(n);
    loops(n);
    array(n);
    return 0;
}
