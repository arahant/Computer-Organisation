#include<stdio.h>
#include "hw1.c"
#include "util.c"

int main(int n, char **args) {
    // CSO 009 HW 01
    q1(args);
    q4();
    q5(args);
    q6(args);

    // util();
    return 0;
}
